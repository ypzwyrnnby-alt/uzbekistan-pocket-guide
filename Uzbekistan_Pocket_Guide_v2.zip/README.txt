UZBEKISTAN POCKET GUIDE V2

Files:
- index.html — complete app
- manifest.json — installable web-app metadata
- sw.js — offline cache

RECOMMENDED IPHONE INSTALL:
1. Upload these files to a static HTTPS host such as GitHub Pages, Netlify or Cloudflare Pages.
2. Open the resulting HTTPS URL in Safari on the iPhone.
3. Use Safari Share -> Add to Home Screen.
4. Enable "Open as Web App" if offered, then Add.
5. Open the new Home Screen icon once while online.
6. Test by enabling Airplane Mode and reopening it.

The app has no external runtime dependencies. Its content is bundled locally.
